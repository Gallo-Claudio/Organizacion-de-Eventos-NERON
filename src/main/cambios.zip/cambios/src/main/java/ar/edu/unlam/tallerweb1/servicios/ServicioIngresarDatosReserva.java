package ar.edu.unlam.tallerweb1.servicios;

public interface ServicioIngresarDatosReserva {
	
	void ingresarDatosReserva(String fecha, String zona, Integer numeroInvitados, String nombre, String apellido,String email, String fingerFood,String bebidas, String evento);
	
	

}
