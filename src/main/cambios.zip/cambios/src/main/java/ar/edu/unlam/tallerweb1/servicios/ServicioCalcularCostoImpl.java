package ar.edu.unlam.tallerweb1.servicios;



import ar.edu.unlam.tallerweb1.dao.calcularCostoDao;
import ar.edu.unlam.tallerweb1.modelo.Reserva;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service("servicioCalcularCosto")
@Transactional
public class ServicioCalcularCostoImpl implements ServicioCalcularCosto {

	
	@Inject
	private calcularCostoDao calcularCostoDao;
	
	@Override
	public Double calcularCosto(Reserva reserva) {
		
	Double total =calcularCostoDao.calcularCosto(reserva);
	return total;
	
		
		
	}

}
