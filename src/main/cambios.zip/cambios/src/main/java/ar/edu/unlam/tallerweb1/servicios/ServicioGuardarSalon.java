package ar.edu.unlam.tallerweb1.servicios;

import ar.edu.unlam.tallerweb1.modelo.Salon;

public interface ServicioGuardarSalon {
	
	void guardarSalon(Salon salon);

}
