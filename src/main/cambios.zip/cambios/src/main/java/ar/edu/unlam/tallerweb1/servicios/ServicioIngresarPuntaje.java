package ar.edu.unlam.tallerweb1.servicios;

import ar.edu.unlam.tallerweb1.modelo.Puntaje;

public interface ServicioIngresarPuntaje {
	

		void ingresarPuntaje(Puntaje puntaje);
	}


