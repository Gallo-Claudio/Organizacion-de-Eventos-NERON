package ar.edu.unlam.tallerweb1.modelo;

import javax.persistence.*;

@Entity
public class Puntaje {
	
	@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private Integer salon;
	
	private Integer menu;
	private Integer show;
	private Integer empleados;
	public Integer getSalon() {
		return salon;
	}
	public void setSalon(Integer salon) {
		this.salon = salon;
	}
	public Integer getShow() {
		return show;
	}
	public void setShow(Integer show) {
		this.show = show;
	}
	public Integer getMenu() {
		return menu;
	}
	public void setMenu(Integer menu) {
		this.menu = menu;
	}
	public Integer getEmpleados() {
		return empleados;
	}
	public void setEmpleados(Integer empleados) {
		this.empleados = empleados;
	}
	
	

}
