package ar.edu.unlam.tallerweb1.dao;




import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;



import ar.edu.unlam.tallerweb1.modelo.Cliente;
import ar.edu.unlam.tallerweb1.modelo.Reserva;


@Repository("calcularCostoDao")
public class calcularCostoDaoImpl implements calcularCostoDao {
	
	@Inject
    private SessionFactory sessionFactory;
	
	@Override
	public Double calcularCosto(Reserva reserva) {
		final Session session = sessionFactory.getCurrentSession();
		Double total=0.0;
	    String tipo=reserva.getFingerFood().getTipoFingerFood();
		Integer invitados=reserva.getNumeroInvitados();
	    switch(tipo) {
	    case "fatay": total = 20.0*invitados;
		break;
		
	    case "bastones de muzzarella y espinaca" : total=10.0* invitados;
	    break;
	    
	    case "sandwich de pollo": total = 20.0*invitados;
		break;
	    
	    case "chips saludables": total = 6.0*invitados;
		break;
		
	    case "brick al huevo": total = 10.0*invitados;
		break;
		
	    case "salchichas con cheddar": total = 10.0*invitados;
		break;
		
	    default:
	    	total=0.0;
	    	break;
	}
	    
	    return total;
	
	

}}
