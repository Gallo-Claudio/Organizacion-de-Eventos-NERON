package ar.edu.unlam.tallerweb1.dao;

import ar.edu.unlam.tallerweb1.modelo.Puntaje;

public interface IngresarPuntajeDao {
		
		void ingresarPuntajeDao(Puntaje puntaje);
	}


