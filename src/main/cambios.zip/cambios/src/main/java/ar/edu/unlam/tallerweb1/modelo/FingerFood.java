package ar.edu.unlam.tallerweb1.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FingerFood {
	
	@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String tipoFingerFood;
	
	private Double precioFatay=20.0;
	

	
	private Double precioBastones=10.0;
	
	private Double precioSandwich=15.0;
	

	
	private Double precioChips=8.0;
	
	
	private Double precioBrick=7.0;
	


private Double precioSalchichas=10.0;



public String getTipoFingerFood() {
	return tipoFingerFood;
}



public void setTipoFingerFood(String tipoFingerFood) {
	this.tipoFingerFood = tipoFingerFood;
}



public Double getPrecioFatay() {
	return precioFatay;
}



public void setPrecioFatay(Double precioFatay) {
	this.precioFatay = precioFatay;
}



public Double getPrecioBastones() {
	return precioBastones;
}



public void setPrecioBastones(Double precioBastones) {
	this.precioBastones = precioBastones;
}



public Double getPrecioSandwich() {
	return precioSandwich;
}



public void setPrecioSandwich(Double precioSandwich) {
	this.precioSandwich = precioSandwich;
}



public Double getPrecioChips() {
	return precioChips;
}



public void setPrecioChips(Double precioChips) {
	this.precioChips = precioChips;
}



public Double getPrecioBrick() {
	return precioBrick;
}



public void setPrecioBrick(Double precioBrick) {
	this.precioBrick = precioBrick;
}



public Double getPrecioSalchichas() {
	return precioSalchichas;
}



public void setPrecioSalchichas(Double precioSalchichas) {
	this.precioSalchichas = precioSalchichas;
}
	


	
	
	
	

}
