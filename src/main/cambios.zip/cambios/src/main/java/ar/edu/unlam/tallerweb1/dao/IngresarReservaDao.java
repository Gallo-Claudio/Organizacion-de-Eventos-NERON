package ar.edu.unlam.tallerweb1.dao;


import ar.edu.unlam.tallerweb1.modelo.Reserva;

public interface IngresarReservaDao {
	
	void ingresarReserva (Reserva reserva);

}
