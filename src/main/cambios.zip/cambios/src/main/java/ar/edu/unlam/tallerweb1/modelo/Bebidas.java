package ar.edu.unlam.tallerweb1.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bebidas {
	
	@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String tipoBebida;
	
	private Double precioGaseosa=20.0;
	

	
	private Double precioGaseosaLight=20.0;
	

	
	private Double precioJugos=15.0;
	

	
	private Double precioCerveza=20.0;



	public String getTipoBebida() {
		return tipoBebida;
	}



	public void setTipoBebida(String tipoBebida) {
		this.tipoBebida = tipoBebida;
	}



	public Double getPrecioGaseosa() {
		return precioGaseosa;
	}



	public void setPrecioGaseosa(Double precioGaseosa) {
		this.precioGaseosa = precioGaseosa;
	}



	public Double getPrecioGaseosaLight() {
		return precioGaseosaLight;
	}



	public void setPrecioGaseosaLight(Double precioGaseosaLight) {
		this.precioGaseosaLight = precioGaseosaLight;
	}



	public Double getPrecioJugos() {
		return precioJugos;
	}



	public void setPrecioJugos(Double precioJugos) {
		this.precioJugos = precioJugos;
	}



	public Double getPrecioCerveza() {
		return precioCerveza;
	}



	public void setPrecioCerveza(Double precioCerveza) {
		this.precioCerveza = precioCerveza;
	}
	

	


	
	

}
