package ar.edu.unlam.tallerweb1.servicios;

import ar.edu.unlam.tallerweb1.modelo.Puntaje;
import ar.edu.unlam.tallerweb1.modelo.Reserva;

public interface ServicioIngresarReserva {

	void ingresarReserva(Reserva reserva);
}
