package ar.edu.unlam.tallerweb1.modelo;

import javax.persistence.*;

@Entity
public class SalonEvento {
	
	@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private Double capacidad;
	
	private String nombre;
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@OneToOne(cascade= CascadeType.ALL)
	private Domicilio ubicacion;
	
	private Double costo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(Double capacidad) {
		this.capacidad = capacidad;
	}

	public Domicilio getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(Domicilio ubicacion) {
		this.ubicacion = ubicacion;
	}

	public Double getCosto() {
		return costo;
	}

	public void setCosto(Double costo) {
		this.costo = costo;
	}

	
	

}
