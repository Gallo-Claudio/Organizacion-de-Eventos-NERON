package ar.edu.unlam.tallerweb1.modelo;

import javax.persistence.*;

@Entity
	public class Salon {
		
		@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Integer id;
		
		private String nombre;
		
		private String zona;
		
		private String fecha;
		
		private Double capacidad;
		
		private Double precio;

		public Double getPrecio() {
			return precio;
		}

		public void setPrecio(Double precio) {
			this.precio = precio;
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getZona() {
			return zona;
		}

		public void setZona(String zona) {
			this.zona = zona;
		}

		

		public String getFecha() {
			return fecha;
		}

		public void setFecha(String fecha) {
			this.fecha = fecha;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public Double getCapacidad() {
			return capacidad;
		}

		public void setCapacidad(Double capacidad) {
			this.capacidad = capacidad;
		}

	

}
