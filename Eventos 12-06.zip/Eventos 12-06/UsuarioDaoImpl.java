package ar.edu.unlam.tallerweb1.dao;

import ar.edu.unlam.tallerweb1.modelo.Cliente;
import ar.edu.unlam.tallerweb1.modelo.Domicilio;
import ar.edu.unlam.tallerweb1.modelo.Reserva;
import ar.edu.unlam.tallerweb1.modelo.Salon;
import ar.edu.unlam.tallerweb1.modelo.SalonEvento;
import ar.edu.unlam.tallerweb1.modelo.Usuario;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.inject.Inject;

// implelemtacion del DAO de usuarios, la anotacion @Repository indica a Spring que esta clase es un componente que debe
// ser manejado por el framework, debe indicarse en applicationContext que busque en el paquete ar.edu.unlam.tallerweb1.dao
// para encontrar esta clase.
@Repository("usuarioDao")
public class UsuarioDaoImpl implements UsuarioDao {

	// Como todo dao maneja acciones de persistencia, normalmente estará inyectado el session factory de hibernate
	// el mismo está difinido en el archivo hibernateContext.xml
	@Inject
    private SessionFactory sessionFactory;

	@Override
	public Usuario consultarUsuario(Usuario usuario) {

		// Se obtiene la sesion asociada a la transaccion iniciada en el servicio que invoca a este metodo y se crea un criterio
		// de busqueda de Usuario donde el email y password sean iguales a los del objeto recibido como parametro
		// uniqueResult da error si se encuentran más de un resultado en la busqueda.
		final Session session = sessionFactory.getCurrentSession();
		return (Usuario) session.createCriteria(Usuario.class)
				.add(Restrictions.eq("email", usuario.getEmail()))
				.add(Restrictions.eq("password", usuario.getPassword()))
				.uniqueResult();
	}

	
	@Override
	public List<Salon> consultarSalon(Salon salon) {

		
		final Session session = sessionFactory.getCurrentSession();
		return (List<Salon>) session.createCriteria(Salon.class)
				.add(Restrictions.eq("capacidad", salon.getCapacidad()))
				.add(Restrictions.eq("precio",salon.getPrecio()))
				.add(Restrictions.eq("zona",salon.getZona())).list();
	}

	
	@Override
	public void crearUsuario(Usuario usuario) {
		final Session session = sessionFactory.getCurrentSession();
		
		session.save(usuario);
		
		
	}

	
	@Override
	public void crearSalon(Salon salon) {
		final Session session = sessionFactory.getCurrentSession();
		
		session.save(salon);
		
		
	}
	
	@Override
	public void crearCliente(Cliente cliente) {
		final Session session = sessionFactory.getCurrentSession();
		
		session.save(cliente);
		
		
	}
	@Override
	public void borrarSalon(Salon salon) {
		final Session session = sessionFactory.getCurrentSession();
		
		session.delete(salon);
		
		
	}

	@Override
	public void borrarCliente(Cliente cliente) {
		final Session session = sessionFactory.getCurrentSession();
		
		session.delete(cliente);
		
		
	}

	@Override
	public void crearReserva(Reserva reserva) {
final Session session = sessionFactory.getCurrentSession();
		
		session.save(reserva);
		
	}

	@Override
	public List<Reserva> consultarReserva(Reserva reserva) {
		final Session session = sessionFactory.getCurrentSession();
		return (List <Reserva>) session.createCriteria(Reserva.class).createAlias("salon", "salonAlias")
				.add(Restrictions.eq("salonAlias.nombre", reserva.getSalon().getNombre())).list();
			
		
	}


	@Override
	public void crearDomicilio(Domicilio domicilio) {
    final Session session = sessionFactory.getCurrentSession();
		
		session.save(domicilio);
		
	}



	
}
