package ar.edu.unlam.tallerweb1.dao;

import java.util.List;

import ar.edu.unlam.tallerweb1.modelo.Cliente;
import ar.edu.unlam.tallerweb1.modelo.Domicilio;
import ar.edu.unlam.tallerweb1.modelo.Reserva;
import ar.edu.unlam.tallerweb1.modelo.Salon;
import ar.edu.unlam.tallerweb1.modelo.SalonEvento;
import ar.edu.unlam.tallerweb1.modelo.Usuario;


// Interface que define los metodos del DAO de Usuarios.
public interface UsuarioDao {
	
	Usuario consultarUsuario (Usuario usuario);
    List<Salon> consultarSalon(Salon salon);
    List<Reserva>consultarReserva(Reserva reserva);
   void crearDomicilio(Domicilio domicilio);
  
	
	void crearUsuario(Usuario usuario);
	
	void crearSalon(Salon salon);
	
	
	void borrarSalon(Salon salon);
	
	void crearCliente(Cliente cliente);
	void crearReserva(Reserva reserva);
	
	
	
	void borrarCliente(Cliente cliente);
}
