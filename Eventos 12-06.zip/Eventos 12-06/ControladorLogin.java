package ar.edu.unlam.tallerweb1.controladores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.springframework.stereotype.Controller;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ar.edu.unlam.tallerweb1.SpringTest;
import ar.edu.unlam.tallerweb1.modelo.Cliente;
import ar.edu.unlam.tallerweb1.modelo.Domicilio;
import ar.edu.unlam.tallerweb1.modelo.Puntaje;
import ar.edu.unlam.tallerweb1.modelo.Reserva;
import ar.edu.unlam.tallerweb1.modelo.Salon;
import ar.edu.unlam.tallerweb1.modelo.SalonEvento;

import ar.edu.unlam.tallerweb1.servicios.ServicioLogin;

@Controller
public class ControladorLogin {

	// La anotacion @Inject indica a Spring que en este atributo se debe setear (inyeccion de dependencias)
	// un objeto de una clase que implemente la interface ServicioLogin, dicha clase debe estar anotada como
	// @Service o @Repository y debe estar en un paquete de los indicados en applicationContext.xml
	
	@Inject
	private ServicioLogin servicioLogin;
	
	
	
	Cliente cliente= new Cliente();
	Cliente juana= new Cliente();
	Cliente luis= new Cliente();
	Cliente angela= new Cliente();
	Reserva reserva= new Reserva();
	Domicilio domicilio= new Domicilio();
	Reserva uno= new Reserva();
	Reserva dos= new Reserva();
	Reserva tres= new Reserva();
	
	List<Reserva> reservas= new ArrayList();
	
	List<Salon>salones=new ArrayList();
	List<String>zonas=new ArrayList();
	Salon rodeo= new Salon();
	Salon donEduardo= new Salon();
	Salon fiesta= new Salon();
	Salon salon= new Salon();
	Puntaje puntaje= new Puntaje();
	
	@RequestMapping(path="/opiniones")
	public ModelAndView verOpiniones() {
		ModelMap modelo= new ModelMap();
		
		
		
	   
	    
	   
		modelo.put("opinionAttribute",this.puntaje);
		
		return new ModelAndView("OpinionUsuarios",modelo);
		
		
		
	}
	
	@RequestMapping(path="/recibirOpinion")
	public ModelAndView recibirOpiniones(@ModelAttribute("opinionAttribute") Puntaje puntaje) {
		ModelMap modelo= new ModelMap();
		
		this.puntaje=puntaje;
		servicioLogin.crearPuntaje(this.puntaje);
		
		
	   
	    
	   
		modelo.put("puntaje",this.puntaje);
		
		return new ModelAndView("OpinionUsuarios",modelo);
		
		
		
	}
	
	
	
	@RequestMapping(path="/domicilio")
	public ModelAndView crearDomicilio() {
		ModelMap modelo= new ModelMap();
		servicioLogin.crearDomicilio(this.domicilio);
		
		
	   
	    
	   
		modelo.put("domicilioAttribute",this.domicilio);
		
		return new ModelAndView("Domicilio",modelo);
		
		
		
	}
	
	@RequestMapping(path="/recibirDomicilio",method=RequestMethod.POST)
	public ModelAndView verdomicilio(@ModelAttribute("domicilioAttribute") Domicilio domicilio) {
		ModelMap modelo= new ModelMap();
		
		this.domicilio=domicilio;
		
	   
	    
	   
		modelo.put("domicilioKey",this.domicilio);
		
		return new ModelAndView("Domicilio",modelo);
		
		
		
	}
	
	@RequestMapping(path="/cliente")
	public ModelAndView crearCliente() {
		ModelMap modelo= new ModelMap();
		servicioLogin.crearCliente(this.cliente);
		
		
	   
	    
	   
		modelo.put("clienteAttribute",this.cliente);
		
		return new ModelAndView("Cliente",modelo);
		
		
		
	}
	
	@RequestMapping(path="/recibirCliente",method=RequestMethod.POST)
	public ModelAndView verCliente(@ModelAttribute("clienteAttribute") Cliente cliente) {
		ModelMap modelo= new ModelMap();
		
		cliente.setDomicilio(this.domicilio);
		this.cliente=cliente;
		
		
	   
	    
	   
		modelo.put("clienteKey",this.cliente);
		
		return new ModelAndView("Cliente",modelo);
		
		
		
	}
	@RequestMapping(path="/salones")
	public ModelAndView salones() {
		ModelMap modelo= new ModelMap();
		
	   
	   this.rodeo.setNombre("rodeo");
	   this.rodeo.setPrecio(6000.0);
	   this.rodeo.setZona("oeste");
	   this.rodeo.setCapacidad(350.0);
	   
	   
	   this.donEduardo.setNombre("donEduardo");
	   this.donEduardo.setPrecio(7000.0);
	   this.donEduardo.setZona("sur");
	   this.donEduardo.setCapacidad(400.0);
	   
	   
	   this.fiesta.setNombre("fiesta");
	   this.fiesta.setPrecio(8000.0);
	   this.fiesta.setZona("oeste");
	   this.fiesta.setCapacidad(400.0);
	    
		servicioLogin.crearSalon(this.rodeo);
		servicioLogin.crearSalon(this.donEduardo);
		servicioLogin.crearSalon(this.fiesta);
		
		modelo.put("rodeoKey",this.rodeo );
		
		
		return new ModelAndView("datos",modelo);
		
		
		
	}
	@RequestMapping(path="/crearReservas")
	public ModelAndView reservas() {
		ModelMap modelo= new ModelMap();
		
		this.angela.setApellido("gimenez");
		this.angela.setDni(1234);
		this.angela.setDomicilio(this.domicilio);
		this.angela.setEmail("angela@yahoo");;
		this.angela.setFechaNacimiento("12/02/1980");
		this.angela.setNombre("angela");
		this.angela.setTelefono(1128990);
		
		this.juana.setApellido("lopez");
		this.juana.setDni(1234);
		this.juana.setDomicilio(this.domicilio);
		this.juana.setEmail("juana@gmail");
		this.juana.setFechaNacimiento("11/08/2000");
		this.juana.setNombre("juana");
		this.juana.setTelefono(1000);
		
		this.luis.setApellido("Mario");
		this.luis.setDni(123433);
		this.luis.setDomicilio(this.domicilio);
		this.luis.setEmail("luis@gmail");
		this.luis.setFechaNacimiento("11/09/1999");
		this.luis.setNombre("Luis");
		this.luis.setTelefono(1009);
		
		servicioLogin.crearCliente(angela);
		servicioLogin.crearCliente(juana);
		servicioLogin.crearCliente(luis);
		
		this.uno.setCliente(this.angela);
		this.uno.setEvento("casamiento");
		this.uno.setFecha("22/04/2019");
		this.uno.setFingerFood("chips");
		this.uno.setNumeroInvitados(180);
		this.uno.setSalon(this.rodeo);
		this.uno.setZona("oeste");
		
		this.dos.setCliente(this.luis);
		this.dos.setEvento("casamiento");
		this.dos.setFecha("22/11/2019");
		this.dos.setFingerFood("chips");
		this.dos.setNumeroInvitados(100);
		this.dos.setSalon(this.fiesta);
		this.dos.setZona("oeste");
		
		this.tres.setCliente(this.juana);
		this.tres.setEvento("casamiento");
		this.tres.setFecha("22/11/2019");
		this.tres.setFingerFood("papas");
		this.tres.setNumeroInvitados(200);
		this.tres.setSalon(this.rodeo);
		this.tres.setZona("sur");
		
		servicioLogin.crearReserva(uno);
		servicioLogin.crearReserva(dos);
		servicioLogin.crearReserva(tres);
		
		
		
		
	   
	
	   
	   
	  
		
		modelo.put("reservaKey",this.uno);
		
		
		return new ModelAndView("clientesYreservas",modelo);
		
		
		
	}
	
	@RequestMapping(path="/salon")
	public ModelAndView crearSalon() {
		ModelMap modelo= new ModelMap();
		
		servicioLogin.crearSalon(this.salon);
		
		
	   
	    
	   
		modelo.put("salonAttribute",this.salon);
		
		return new ModelAndView("salones",modelo);
		
		
		
	}
	
	
		
	
	@RequestMapping(path="/buscarSalon",method=RequestMethod.POST)
	public ModelAndView verSalon(@ModelAttribute("salonAttribute") Salon salon) {
		ModelMap modelo= new ModelMap();
		
		
		
		
		this.salones=servicioLogin.consultarSalon(salon);
		
	
	    
	   
		modelo.put("salonesKey",this.salones);
		
		
		return new ModelAndView("salonesDisponibles",modelo);
		
		
		
	}
	
	@RequestMapping(path="/seleccionarSalon")
	public ModelAndView seleccion(@RequestParam("nombre") String nombre) {
		ModelMap modelo= new ModelMap();
		 Salon seleccionado= new Salon();
		 servicioLogin.crearSalon(seleccionado);
		 
		for(Salon s: this.salones) {
			if(s.getNombre()==nombre) {
				 seleccionado=s;
			}
		}
		this.reserva.setSalon(seleccionado);
		servicioLogin.crearReserva(this.reserva);
		
		
		modelo.put("nombreKey", nombre);
		
		return new ModelAndView ("salonesDisponibles",modelo);
		
		
		
	}
	
	
	@RequestMapping(path="/reserva")
	public ModelAndView crearReserva() {
		ModelMap modelo= new ModelMap();
		
		servicioLogin.crearReserva(this.reserva);
		
		
	   
	    
	   
		modelo.put("reservaAttribute",this.reserva);
		
		return new ModelAndView("reserva",modelo);
		
		
		
	}
	
	@RequestMapping(path="/recibirReserva",method=RequestMethod.POST)
	public ModelAndView verReserva(@ModelAttribute("reservaAttribute") Reserva reserva) {
		ModelMap modelo= new ModelMap();
		
		reserva.setSalon(this.reserva.getSalon());
		
		
		this.reserva=reserva;
		
		servicioLogin.crearReserva(this.reserva);
		
		
		this.reservas=servicioLogin.consultarReserva(this.reserva);
		
		for(Reserva r:this.reservas) {
			this.zonas.add(r.getZona());
		}
	
	    
	   modelo.put("zonaKey", this.zonas);
		modelo.put("reservasKey",this.reservas);
		
		return new ModelAndView("reserva",modelo);
		
		
		
	}
	
	
		

			
			
			
		
		 
		 
		
	
	
	
/*
	
	
	
	
/*
	
	
	
	
	@RequestMapping(path="/buscarSalonesEvento")
	public ModelAndView mostrarFormularioE() {
		ModelMap modelo= new ModelMap();
	    SalonEvento salonAbuscar = new SalonEvento();
	   
	    
	  
		
		modelo.put("formAttribute", salonAbuscar);
		
		return new ModelAndView("FormularioCateringEvento",modelo);
		
		
		
	}
	

	@RequestMapping(path="/recibirFormularioCateringEvento",method=RequestMethod.POST)
	public ModelAndView FormularioEvento(@ModelAttribute("formAttribute")SalonEvento salon) {
		ModelMap modelo= new ModelMap();
		
		SalonEvento encontrado=servicioLogin.consultarSalon(salon);
		
		modelo.put("encontradoKey", encontrado);
		
		
		
		
		return new ModelAndView("FormularioCateringEvento",modelo);
		
		
		
	}
	
	
	
	
	
	
	
	@RequestMapping(path="/recibirFormularioCatering",method=RequestMethod.POST)
	public ModelAndView Formulario(@ModelAttribute("formAttribute")Salon salonAbuscar) {
		ModelMap modelo= new ModelMap();
		
		String zona= salonAbuscar.getZona();
		 String mensaje="Nada";
		for(Salon s:listaSalones) {
		if(s.getZona() == zona ) {
			 mensaje="encontrado";
		}
		}
		
		modelo.put("salonKey", salonAbuscar);
		modelo.put("mensajeKey", mensaje);
		modelo.put("listaKey", listaSalones);
		
		
		
		return new ModelAndView("FormularioCatering",modelo);
		
		
		
	}
	
	
	@RequestMapping(path="/recibirFormGet")
	public ModelAndView FormularioGet(@RequestParam("value") String nombre,@RequestParam("valueDos") String apellido) {
		ModelMap modelo= new ModelMap();
		
		modelo.put("nombrek", nombre);
		modelo.put("apellidok", apellido);
		
		Formulario formulario= new Formulario();
		formulario.setNombre(nombre);
		modelo.put("fkey", formulario);
		
		
		
		
		return new ModelAndView("formularioTres",modelo);
		
		
		
	}
	
	
	
	@RequestMapping(path="/recibirFormCat")
	public ModelAndView FormularioC(@RequestParam("value") String nombre,@RequestParam("valueDos") String apellido) {
		ModelMap modelo= new ModelMap();
		
		modelo.put("nombrek", nombre);
		modelo.put("apellidok", apellido);
		
		
		
		
		
		
		return new ModelAndView("FormularioCatering",modelo);
		
		
		
	}
		
	
	
	
	
	
/*
	
	
	
	
	
	
	
	@RequestMapping(path="/")
	public ModelAndView pasarAMayuscula(@RequestParam("op") String operacion,@RequestParam("car") String caracteres) {
		
		String resultado="";
		if(operacion=="mayuscula") {
		
           resultado = caracteres.toUpperCase();
	}
		
		ModelMap modelo= new ModelMap();
		
		modelo.put("opKey", operacion);
		modelo.put("resKey",resultado);
		modelo.put("carKey", caracteres);
		
		
		return new ModelAndView("vistaoperacion",modelo);
		
		
		
	}*/
	
	
	/*
	@RequestMapping(path="/operaciones/{operacion}/{caracteres}")
	public ModelAndView cambiarCaracteres(@PathVariable("caracteres") String cadena,@PathVariable("operacion") String operacion ) {

		ModelMap modelo = new ModelMap();
		String resultado="";
		
		if(operacion == "pasarAMayuscula") {
		 resultado= cadena.toUpperCase();
		}else if(operacion=="invertirOrden") {
			char[] invertir= cadena.toCharArray();
			 String invertido="";
			
				for(int j=invertir.length-1;j>=0;j--) {
			   
				invertido+= invertir[j];
			
		      }
				 resultado= invertido;
				                              }
		
		modelo.put("cadenaKey", cadena);
		modelo.put("operacionKey", operacion);
		modelo.put("cadenaResultadoKey",resultado);
		
		return new ModelAndView("cadenaResultado",modelo);}
	
	@RequestMapping("/formulario")
	public ModelAndView irAFormulario() {
		
		Formulario formulario= new Formulario();
		ModelMap modelo = new ModelMap();
		
		modelo.put("formularioAttribute", formulario);
		
		return new ModelAndView("formulario",modelo);
		
	}
	

    
	
	
	/*@RequestMapping(path="/recibirFormularioGet",method=RequestMethod.GET)
	public ModelAndView recibirGet(@RequestParam("nombre") String nombre){
		
		/*Integer id=0;
		ModelMap modelo= new ModelMap();
		Formulario f = new Formulario();
		if(f.getNombre()==nombre) {
			 id=f.getId();
		}
		ModelMap modelo= new ModelMap();
	
		
		modelo.put("nombreKey", nombre);
		
		
		
		
		return new ModelAndView("formularioDos",modelo);
	} 


	// Este metodo escucha la URL localhost:8080/NOMBRE_APP/login si la misma es invocada por metodo http GET
	@RequestMapping("modelos/login")
	public ModelAndView irALogin() {

		ModelMap modelo = new ModelMap();
		// Se agrega al modelo un objeto del tipo Usuario con key 'usuario' para que el mismo sea asociado
		// al model attribute del form que esta definido en la vista 'login'
		Usuario usuario = new Usuario();
		modelo.put("usuario", usuario);
		// Se va a la vista login (el nombre completo de la lista se resuelve utilizando el view resolver definido en el archivo spring-servlet.xml)
		// y se envian los datos a la misma  dentro del modelo
		return new ModelAndView("login", modelo);
	}
	
	@RequestMapping(path="/saludar/{nombrePath}/{repeticionesPath}")
	public ModelAndView decirHola(@PathVariable("nombrePath") String nombre,@PathVariable("repeticionesPath") Integer repeticiones) {

		ModelMap modelo = new ModelMap();
		
		List<String> lista= new ArrayList();
		
		
		for(int i=0; i< repeticiones; i++) {
			lista.add(nombre);
		}
		
		modelo.put("listaKey", lista);
		
		return new ModelAndView("lista",modelo);
		
	}
		
	
			
			
		
	
	
	/*@RequestMapping(path="/saludarOtraVez/{nombrePath}/{repeticionesPath}")
	public ModelAndView decirHolaOtraVez(@PathVariable("nombrePath") String nombre,@PathVariable("repeticionesPath") Integer repeticiones) {

		ModelMap modelo = new ModelMap();
		
		List<String> lista= new ArrayList();
		
		
		lista.add(nombre);
		
		
		modelo.put("listaKey", lista);
		
		return new ModelAndView("listaDos", modelo);
	}*/
	
/*	@RequestMapping("/usuario")
	public ModelAndView mostrarUsuario() {

		ModelMap modelo = new ModelMap();
		// Se agrega al modelo un objeto del tipo Usuario con key 'usuario' para que el mismo sea asociado
		// al model attribute del form que esta definido en la vista 'login'
	//	Usuario usuario = new Usuario();
		//usuario.setEmail("emailUsuario");
		//modelo.put("usuario", usuario);
		// Se va a la vista login (el nombre completo de la lista se resuelve utilizando el view resolver definido en el archivo spring-servlet.xml)
		// y se envian los datos a la misma  dentro del modelo
		/*if(modelo.isEmpty()) {
			return new ModelAndView("UsuarioInvalido");
		}else {
		return new ModelAndView("usuarioValido", modelo);
	}}
	
	@RequestMapping("/holaMundo")
	public ModelAndView decirHola() {

		ModelMap modelo = new ModelMap();
		
		Usuario usuario = new Usuario();
		usuario.setEmail("@yahoo.com");
		usuario.setRol("a");
		
		Usuario dos = new Usuario();
		dos.setEmail("emailDos");
		dos.setRol("b");
		modelo.put("nombre","agus");
		modelo.put("usuarioUno", usuario);
		modelo.put("usuarioDos", dos);
		
		
		return new ModelAndView("hola", modelo);
	}
	
	@RequestMapping(path = "variables/{caracteres}")
	public ModelAndView cambiarCaracteres(@PathVariable("caracteres") String cadena) {
		ModelMap model = new ModelMap();
		
		String cadenaAconvertir= cadena.toUpperCase();
		
		model.put("cadenaModel", cadenaAconvertir + cadena);

		
			return new ModelAndView("cadena",model);
		}

	// Este metodo escucha la URL validar-login siempre y cuando se invoque con metodo http POST
	// El método recibe un objeto Usuario el que tiene los datos ingresados en el form correspondiente y se corresponde con el modelAttribute definido en el
	// tag form:form
	@RequestMapping(path = "/validar-login", method = RequestMethod.POST)
	public ModelAndView validarLogin(@ModelAttribute("usuario") Usuario usuario, HttpServletRequest request) {
		ModelMap model = new ModelMap();
	

		// invoca el metodo consultarUsuario del servicio y hace un redirect a la URL /home, esto es, en lugar de enviar a una vista
		// hace una llamada a otro action a través de la URL correspondiente a ésta
		Usuario usuarioBuscado = servicioLogin.consultarUsuario(usuario);
		
		servicioLogin.crearUsuario(usuario);
		if (usuarioBuscado != null) {
			request.getSession().setAttribute("ROL", usuarioBuscado.getRol());
			return new ModelAndView("redirect:/home");
		} else {
			// si el usuario no existe agrega un mensaje de error en el modelo.
			model.put("error", "Usuario o clave incorrecta");
		}
		return new ModelAndView("login", model);
	}
	
	/*@RequestMapping(path = "/recibirForm", method = RequestMethod.POST)
	public ModelAndView formulario(@ModelAttribute("FormAttribute") Formulario form,HttpServletRequest request) {
		ModelMap model = new ModelMap();
		
	    // model.put("formKey", form);

		
		
		return new ModelAndView("formulario", model);
	}
	
	@RequestMapping(path ="/formulario", method = RequestMethod.GET)
	public ModelAndView verformulario() {
		ModelMap model = new ModelMap();
	    Formulario f= new Formulario();
	    
	    model.put("FormAttribute",f);

		
		
		return new ModelAndView("formulario",model);
	}

	// Escucha la URL /home por GET, y redirige a una vista.
	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public ModelAndView irAHome() {
		return new ModelAndView("home");
	}

	// Escucha la url /, y redirige a la URL /login, es lo mismo que si se invoca la url /login directamente.
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public ModelAndView inicio() {
		return new ModelAndView("redirect:/login");
	}*/
}
