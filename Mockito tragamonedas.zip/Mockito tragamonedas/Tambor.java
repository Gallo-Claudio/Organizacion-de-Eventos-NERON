package ar.edu.unlam.tallerweb1.modelo;

public class Tambor {

	public int girar(int numero) {

		int cara = (int) (Math.random() * 10);

		return cara;
	}

}
