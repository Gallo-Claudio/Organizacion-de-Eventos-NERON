package ar.edu.unlam.tallerweb1.modelo;

public class Tragamonedas {

	private Tambor t1;
	private Tambor t2;
	private Tambor t3;

	public Tragamonedas(Tambor t1, Tambor t2, Tambor t3) {
		this.t1 = new Tambor();
		this.t2 = new Tambor();
		this.t3 = new Tambor();

	}

	public Boolean jugar(int uno, int dos, int tres) {
		int v1 = t1.girar(uno);
		int v2 = t2.girar(dos);
		int v3 = t3.girar(tres);
		if (v1 == v2 && v2 == v3) {
			return true;
		}
		return false;
	}

}
