package ar.edu.unlam.tallerweb1.persistencia;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlam.tallerweb1.SpringTest;
import ar.edu.unlam.tallerweb1.modelo.Tambor;
import ar.edu.unlam.tallerweb1.modelo.Tragamonedas;

import org.junit.Test;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;
import static org.assertj.core.api.Assertions.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TestMockito extends SpringTest {

	@Test
	public void usuarioGano() {
		Tambor t1 = mock(Tambor.class);
		Tambor t2 = mock(Tambor.class);
		Tambor t3 = mock(Tambor.class);

		when(t1.girar(3)).thenReturn(2);

		when(t2.girar(5)).thenReturn(2);
		when(t3.girar(4)).thenReturn(2);

		Tragamonedas tragamonedas = new Tragamonedas(t1, t2, t3);
		Boolean gano = tragamonedas.jugar(8,9,0);

		assertTrue(gano);

	}

	@Test
	public void usuarioperdio() {
		Tambor t1 = mock(Tambor.class);
		Tambor t2 = mock(Tambor.class);
		Tambor t3 = mock(Tambor.class);

		when(t1.girar(4)).thenReturn(2);

		when(t2.girar(7)).thenReturn(3);
		when(t3.girar(8)).thenReturn(2);

		Tragamonedas tragamonedas = new Tragamonedas(t1, t2, t3);
		Boolean gano = tragamonedas.jugar(2,5,6);
		assertFalse(gano);

	}
	
	@Test
	public void probarController() {
		
		//personaController pc= new personaController();
		//settear mock creado en el controlador  pc.setpersonaServicio();

	}

}
